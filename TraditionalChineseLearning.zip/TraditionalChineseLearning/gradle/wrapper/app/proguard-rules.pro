# 保持数据类
-keep class com.example.tradchinese.model.** { *; }
-keep class com.example.tradchinese.data.** { *; }