package com.example.tradchinese.viewmodel

import androidx.lifecycle.ViewModel
import com.example.tradchinese.data.CharacterData
import com.example.tradchinese.model.CharacterPair
import com.example.tradchinese.model.QuizRecord
import com.example.tradchinese.model.QuizState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class QuizViewModel : ViewModel() {

    private val allCharacters = CharacterData.getAllCharacters()
    private val usedIndices = mutableSetOf<Int>()

    private val _quizState = MutableStateFlow(QuizState())
    val quizState: StateFlow<QuizState> = _quizState.asStateFlow()

    private val _learningList = MutableStateFlow(allCharacters)
    val learningList: StateFlow<List<CharacterPair>> = _learningList.asStateFlow()

    private val _learningSearchQuery = MutableStateFlow("")
    val learningSearchQuery: StateFlow<String> = _learningSearchQuery.asStateFlow()

    init {
        nextQuestion()
    }

    fun nextQuestion() {
        if (usedIndices.size >= allCharacters.size) {
            usedIndices.clear()
        }

        var index: Int
        do {
            index = (allCharacters.indices).random()
        } while (index in usedIndices)

        usedIndices.add(index)
        val char = allCharacters[index]

        _quizState.update {
            it.copy(
                currentChar = char,
                revealed = false,
                answered = false
            )
        }
    }

    fun reveal() {
        _quizState.update {
            it.copy(revealed = true, answered = false)
        }
    }

    fun markCorrect() {
        _quizState.update { state ->
            val newCombo = state.combo + 1
            val record = QuizRecord(
                traditional = state.currentChar?.traditional ?: "",
                simplified = state.currentChar?.simplified ?: "",
                pinyin = state.currentChar?.pinyin ?: "",
                correct = true
            )
            state.copy(
                totalQuestions = state.totalQuestions + 1,
                correctCount = state.correctCount + 1,
                combo = newCombo,
                maxCombo = maxOf(state.maxCombo, newCombo),
                answered = true,
                lastCorrect = true,
                history = state.history + record
            )
        }
    }

    fun markWrong() {
        _quizState.update { state ->
            val record = QuizRecord(
                traditional = state.currentChar?.traditional ?: "",
                simplified = state.currentChar?.simplified ?: "",
                pinyin = state.currentChar?.pinyin ?: "",
                correct = false
            )
            state.copy(
                totalQuestions = state.totalQuestions + 1,
                combo = 0,
                answered = true,
                lastCorrect = false,
                history = state.history + record
            )
        }
    }

    fun resetStats() {
        usedIndices.clear()
        _quizState.value = QuizState()
        nextQuestion()
    }

    fun searchLearning(query: String) {
        _learningSearchQuery.value = query
        _learningList.value = if (query.isBlank()) {
            allCharacters
        } else {
            allCharacters.filter {
                it.traditional.contains(query, ignoreCase = true) ||
                        it.simplified.contains(query, ignoreCase = true) ||
                        it.pinyin.contains(query, ignoreCase = true)
            }
        }
    }
}