package com.example.tradchinese

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.tradchinese.ui.screens.HomeScreen
import com.example.tradchinese.ui.screens.LearningScreen
import com.example.tradchinese.ui.screens.QuizScreen
import com.example.tradchinese.ui.theme.TraditionalChineseTheme
import com.example.tradchinese.viewmodel.QuizViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TraditionalChineseTheme {
                MainApp()
            }
        }
    }
}

enum class Screen {
    HOME, QUIZ, LEARNING
}

@Composable
fun MainApp() {
    val quizViewModel: QuizViewModel = viewModel()
    val quizState by quizViewModel.quizState.collectAsState()
    val learningList by quizViewModel.learningList.collectAsState()
    val learningSearchQuery by quizViewModel.learningSearchQuery.collectAsState()

    var currentScreen by remember { mutableStateOf(Screen.HOME) }

    AnimatedContent(
        targetState = currentScreen,
        transitionSpec = {
            if (targetState == Screen.HOME) {
                slideInHorizontally { -it } + fadeIn() togetherWith
                        slideOutHorizontally { it } + fadeOut()
            } else {
                slideInHorizontally { it } + fadeIn() togetherWith
                        slideOutHorizontally { -it } + fadeOut()
            }
        },
        label = "screen_transition"
    ) { screen ->
        when (screen) {
            Screen.HOME -> HomeScreen(
                onQuizClick = { currentScreen = Screen.QUIZ },
                onLearningClick = { currentScreen = Screen.LEARNING }
            )

            Screen.QUIZ -> QuizScreen(
                quizState = quizState,
                onReveal = { quizViewModel.reveal() },
                onCorrect = { quizViewModel.markCorrect() },
                onWrong = { quizViewModel.markWrong() },
                onNext = { quizViewModel.nextQuestion() },
                onReset = { quizViewModel.resetStats() },
                onBack = { currentScreen = Screen.HOME }
            )

            Screen.LEARNING -> LearningScreen(
                characters = learningList,
                searchQuery = learningSearchQuery,
                onSearchChange = { quizViewModel.searchLearning(it) },
                onBack = { currentScreen = Screen.HOME }
            )
        }
    }
}