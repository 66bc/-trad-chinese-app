package com.example.tradchinese.model

data class CharacterPair(
    val traditional: String,
    val simplified: String,
    val pinyin: String,
    val meaning: String = ""
)

data class QuizState(
    val currentChar: CharacterPair? = null,
    val revealed: Boolean = false,
    val totalQuestions: Int = 0,
    val correctCount: Int = 0,
    val combo: Int = 0,
    val maxCombo: Int = 0,
    val answered: Boolean = false,
    val lastCorrect: Boolean = false,
    val history: List<QuizRecord> = emptyList()
) {
    val accuracy: Float
        get() = if (totalQuestions > 0) correctCount.toFloat() / totalQuestions else 0f

    val accuracyPercent: String
        get() = if (totalQuestions > 0) "${(accuracy * 100).toInt()}%" else "-"
}

data class QuizRecord(
    val traditional: String,
    val simplified: String,
    val pinyin: String,
    val correct: Boolean
)